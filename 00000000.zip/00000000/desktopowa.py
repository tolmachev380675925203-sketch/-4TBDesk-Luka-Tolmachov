import random
import tkinter as tk
from tkinter import ttk, messagebox

NUMER = "00000000000"
MALE = "abcdefghijklmnopqrstuvwxyz"
WIELKIE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
CYFRY = "0123456789"
SPECJALNE = "!@#$%^&*()_+-="

haslo = ""

okno = tk.Tk()
okno.title("Dodaj pracownika " + NUMER)
okno.configure(bg="#B0C4DE", padx=20, pady=15)




ramka1 = tk.LabelFrame(okno, text="Dane pracownika", bg="#B0C4DE", padx=15, pady=15)
ramka1.grid(row=0, column=0, padx=10)



tk.Label(ramka1, text="Imię", bg="#B0C4DE").grid(row=0, column=0, pady=8)
pole_imie = tk.Entry(ramka1)
pole_imie.grid(row=0, column=1)



tk.Label(ramka1, text="Nazwisko", bg="#B0C4DE").grid(row=1, column=0, pady=8)
pole_nazwisko = tk.Entry(ramka1)
pole_nazwisko.grid(row=1, column=1)




tk.Label(ramka1, text="Stanowisko", bg="#B0C4DE").grid(row=2, column=0, pady=8)
lista = ttk.Combobox(ramka1, values=["Kierownik", "Starszy programista", "Młodszy programista", "Tester"])
lista.grid(row=2, column=1)



ramka2 = tk.LabelFrame(okno, text="Generowanie hasła", bg="#B0C4DE", padx=15, pady=15)
ramka2.grid(row=0, column=1, padx=10)




tk.Label(ramka2, text="Ile znaków?", bg="#B0C4DE").grid(row=0, column=0, pady=8)
pole_dlugosc = tk.Entry(ramka2)
pole_dlugosc.grid(row=0, column=1)




litery = tk.BooleanVar(value=True)
cyfry = tk.BooleanVar()
specjalne = tk.BooleanVar()
tk.Checkbutton(ramka2, text="Małe i wielkie litery", variable=litery, bg="#B0C4DE").grid(row=1, column=0, columnspan=2, sticky="w")
tk.Checkbutton(ramka2, text="Cyfry", variable=cyfry, bg="#B0C4DE").grid(row=2, column=0, columnspan=2, sticky="w")
tk.Checkbutton(ramka2, text="Znaki specjalne", variable=specjalne, bg="#B0C4DE").grid(row=3, column=0, columnspan=2, sticky="w")


def generuj():
    global haslo
    dlugosc = int(pole_dlugosc.get())
    znaki = []
    for i in range(dlugosc):
        znaki.append(random.choice(MALE))
    if litery.get():
        znaki[0] = random.choice(WIELKIE)
    if cyfry.get():
        znaki[1] = random.choice(CYFRY)
    if specjalne.get():
        znaki[2] = random.choice(SPECJALNE)
    haslo = "".join(znaki)
    messagebox.showinfo("Hasło", haslo)



def zatwierdz():
    tekst = "Dane pracownika: " + pole_imie.get() + " " + pole_nazwisko.get() + " " + lista.get() + " Hasło: " + haslo
    messagebox.showinfo("Dane pracownika", tekst)





tk.Button(ramka2, text="Generuj hasło", bg="#4682B4", fg="white", command=generuj).grid(row=4, column=0, columnspan=2, pady=8)







tk.Button(okno,text="Zatwierdź",bg="#4682B4",fg="white",command=zatwierdz).grid(row=1,column=0,columnspan=2,sticky="ew",padx=120, pady=15)




okno.mainloop()